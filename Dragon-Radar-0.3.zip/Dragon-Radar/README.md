# Dragon Radar 0.3

Pradinis Android projekto karkasas.

## Kas jau yra
- Klasikinis tamsiai žalias radaro ekranas su koncentriniais žiedais ir kryžiumi.
- GPS leidimo užklausa ir dabartinės vietos / tikslumo rodymas.
- GitHub Actions darbo eiga, kuri sukompiliuoja debug APK ir pateikia jį kaip artefaktą.

## Kas dar neįgyvendinta
- Atstumas iki radaro taikinio: reikia tikro taikinio koordinačių arba naudotojo pasirinkto taško. Programa jų neišgalvoja.
- Taikinio pulsuojantis taškas ir paieškos logika.
- Originalus garso signalas: įdėsime savą garsą, ne kopijuotą anime įrašą.

## APK kūrimas
Įkelk šiuos failus į `KPukas/Dragon-radar` pagrindinę šaką (`main` arba `master`).
GitHub Actions → Build Dragon Radar APK → po sėkmingo paleidimo atsisiųsk `dragon-radar-debug-apk` artefaktą.
